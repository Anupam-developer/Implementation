var nodemailer = require('nodemailer');

var transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'anupampatel1994@gmail.com',
    pass: ''
  }
});

var mailOptions = {
  from: 'anupampatel1994@gmail.com',
  to: 'sukhpal.singh@mail.vinove.com',
  subject: 'Sending Email using Node.js',
  html: '<h1>Hey Sukhpal</h1><p>That was quite easy to send mail using node js. .!</p>'
};

transporter.sendMail(mailOptions, function(error, info){
  if (error) {
    console.log(error);
  } else {
    console.log('Email sent: ' + info.response);
  }
});