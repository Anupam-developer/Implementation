const express = require('express');
const fs = require('fs');
const route = express.Router();
const path = require('path');
const nodemailer = require('nodemailer');
const multer = require('multer');

const storage = multer.diskStorage({
    destination: './public/uploads',
    filename: function (req, file, cb) {
        cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
    }
});

let upload = multer({
    storage: storage,
    limits: { fileSize: 1000000 },
    fileFilter: (req, file, cb) => {
        checkFileType(file, cb)
    }
}).single('single');

checkFileType = (file, cb) => {
    let filetypes = /img|jpeg|jpg|png/;
    let extname = filetypes.test(path.extname(file.originalname).toLowerCase());
    let mimetype = filetypes.test(file.mimetype);
    if (mimetype || extname) {
        return cb(null, true);
    } else {
        cb('Error: ' + filetypes + ' only')
    }
}
const p = path.join(__dirname, 'data.json')
function read(cb) {

    fs.readFile(p, (err, fileContent) => {
        if (err) {
            cb([]);
        } else {
            cb(JSON.parse(fileContent));
        }
    })
}

function save(user, cb) {
    read(users => {
        users.push(user);
        fs.writeFileSync(p, JSON.stringify(users), cb(users))

    })
}
let administrator;
const username = 'admin';
const password = 'administrator';

route.post('/', (req, res, next) => {

    if (req.body.name !== '' && req.body.email !== '' && req.body.pswd !== '') {
        isTrue = true;
        if (isTrue && req.body.pswd === req.body.pswd1) {
            const user =
            {
                id: Date.now(),
                name: req.body.name,
                email: req.body.email,
                Password: req.body.pswd,
                address: req.body.add,
                mobile: req.body.mob
            };

            fs.readFile("data.json", 'utf8', function (err, data) {
                var d = JSON.parse(data);
                var u = d.find(el => {
                    return el.email === req.body.email;
                })
                if (!u) {
                    save(user, users => {
                        console.log('Submitted Successfully')
                    });
                    res.render('login')
                }
                else {
                    res.render('account', {
                        msg: "Email already exist,please try with different email"
                    })
                }
            })
        }
        else {
            isTrue = false;
            return res.render('account', {
                msg: 'password do not match'
            })
        }
    }
    else {
        res.render('account', {
            msg: 'Fields can not be left empty'
        });
    }
});


route.get('/admin', (req, res, next) => {
    res.render('admin');
})
route.post('/admin', (req, res, next) => {
    if (username === req.body.name && password === req.body.pswd) {
        console.log("inside if")
        isTrue = true;
        administrator = { email: username, password: password }
        req.session.user = administrator;
        if (isTrue) {
            res.send('<script> setTimeout(() => { window.location.href="http://localhost:8081/details"; },300);</script>');
        }
        else {
            res.render('admin', {
                msg: 'Invalid Credentials'
            })
        }
    }
});

route.get('/login', (req, res, next) => {
    res.render('login');
})
route.post('/login', (req, res, next) => {
    const email = req.body.username;
    const password = req.body.pswd;
    const user = { email: email, password: password }

    fs.readFile("data.json", 'utf8', function (err, data) {
        var d = JSON.parse(data);
        var u = d.find((el) => {
            return el.email == email;
        })
        console.log(email, u)
        if (u && u.email === email && u.Password === password) {
            req.session.user = user;
            res.render('logged', {
                msg: u
            })
        } else {
            return res.render('login', {
                msg: "Invalid Username Or Password"
            })
        }
    })

});


route.get('/details/:id', (req, res, next) => {
    if (!req.session.user) {
        console.log('first')
        return res.redirect('/')
    }
    next()
}, function (req, res) {

    console.log("inside details/id")
    fs.readFile("data.json", 'utf8', function (err, data) {
        var d = JSON.parse(data);

        var u = d.find((el) => {
            return el.id == req.params.id;
        })

        res.render('details', {
            msg: u
        })

    });
})


route.get('/details', (req, res, next) => {
    if (!req.session.user) {
        console.log('first')
        return res.redirect('/')
    }
    next()
}, function (req, res) {
    console.log("details")
    console.log('hi');
    read(users => {
        res.render('users', { users: users })
    })
})

route.get('/delete/:userId', (req, res, next) => {
    if (!req.session.user) {
        console.log('first')
        return res.redirect('/')
    }
    next()
}, (req, res, next) => {
    console.log("insid delete by id")
    const userId = req.params.userId;
    console.log(userId);
    read(users => {
        const AllUsers = [...users];
        updatedUsers = AllUsers.filter(user => {
            return user.id.toString() !== userId.toString();
        });
        fs.writeFileSync(p, JSON.stringify(updatedUsers))
        console.log("callback")

    })
    res.send('<script> setTimeout(() => { window.location.href="http://localhost:8081/details";}, 300);</script>');
})

route.get('/edit/:userId', (req, res, next) => {
    if (!req.session.user) {
        console.log('first')
        return res.redirect('/')
    }
    next()
}, (req, res, next) => {
    console.log("insid edit by id")
    const userId = req.params.userId;
    fs.readFile("data.json", 'utf8', function (err, data) {
        var d = JSON.parse(data);
        var u = d.find((el) => {
            return el.id == userId;
        })
        res.render('edit', {
            msg: u
        })

    });
})

route.post('/edit-user', (req, res, next) => {
    if (!req.session.user) {
        console.log('first')
        return res.redirect('/')
    }
    next()
}, (req, res, next) => {
    if (req.body.pswd === req.body.pswd1 && typeof req.body.pswd1 !== 'undefined') {
        const data = {
            name: req.body.name,
            id: req.body.userId,
            email: req.body.email,
            Password: req.body.pswd,
            mobile: req.body.mob,
            address: req.body.add
        }
        read(users => {
            const updatedUsers = [...users]
            const userIndex = updatedUsers.findIndex(user => {
                return user.id.toString() === data.id.toString();
            })
            const userToUpdate = updatedUsers[userIndex];
            userToUpdate.name = data.name
            userToUpdate.email = data.email
            userToUpdate.Password = data.Password
            userToUpdate.mobile = data.mobile
            userToUpdate.address = data.address
            updatedUsers[userIndex] = userToUpdate
            fs.writeFileSync(p, JSON.stringify(updatedUsers))
        })
        if (req.session.user.email === data.email) {
            res.render('logged', {
                msg: data
            })
        }
        else {
            res.send('<script> setTimeout(() => { window.location.href="http://localhost:8081/details";}, 300);</script>');
        }

    } else {
        res.render('account', {
            msg: 'Not Updated'
        })
    }
});

route.get('/email', (req, res) => {
    res.render('email');
});

route.post('/email', (req, res) => {
    var transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: req.body.from,
            pass: req.body.password
        }
    });
    var mailOptions = {
        from: req.body.from,
        to: req.body.to,
        subject: req.body.subject,
        html: req.body.area
    };

    console.log(mailOptions);
    transporter.sendMail(mailOptions, function (error, info) {
        if (error) {
            console.log(error);
        } else {
            res.render('email', {
                msg: 'Email Sent Successfully' + info.response
            })
            console.log('Email sent: ' + info.response);
        }
    });
})

route.get('/upload', (req, res) => res.render('multer'));

route.post('/upload', (req, res) => {
    upload(req, res, (err) => {
        if (err) {
            res.render('multer', {
                msg: err,
            });
        }
        else {
            if (req.file === undefined) {
                res.render('multer', {
                    msg: 'ERROR: No File Selected'
                });
            } else {
                res.render('multer', {
                    msg: 'File Uploaded Successfully',
                    file: `uploads/${req.file.filename}`
                })
                console.log(req.file);
            }
        };
    });
});

route.post('/logout', (req, res) => {
    req.session.destroy(err => {
        console.log('Logged Out');
    });
    res.redirect('/login');
})
module.exports = route;
